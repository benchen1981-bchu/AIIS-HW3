Download the 'creditcard' dataset in .csv format from the following link:
https://www.openml.org/data/get_csv/1673544/phpKo8OWT

Dataset License: https://www.openml.org/d/1597
(PUBLIC DOMAIN: https://creativecommons.org/publicdomain/mark/1.0/)

Dataset Credits:
Author: Andrea Dal Pozzolo, Olivier Caelen and Gianluca Bontempi
Source: Credit card fraud detection - Date 25th of June 2015
Please cite: Andrea Dal Pozzolo, Olivier Caelen, Reid A. Johnson and Gianluca Bontempi. 
Calibrating Probability with Undersampling for Unbalanced Classification. 
In Symposium on Computational Intelligence and Data Mining (CIDM), IEEE, 2015

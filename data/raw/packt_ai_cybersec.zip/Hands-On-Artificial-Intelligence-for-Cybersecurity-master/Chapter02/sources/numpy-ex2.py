import numpy as np

a = np.array([-8, 15])

X = np.array([[1, 5], 
              [3, 4],  
              [2, 3]])

y = np.dot(X, a)

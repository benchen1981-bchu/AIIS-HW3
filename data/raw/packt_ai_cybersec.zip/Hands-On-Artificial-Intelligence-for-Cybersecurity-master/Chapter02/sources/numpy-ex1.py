import numpy as np
 
np_array = np.array( [0, 1, 2, 3] )

# Creating an array with ten elements initialized as zero

np_zero_array = np.zeros(10)


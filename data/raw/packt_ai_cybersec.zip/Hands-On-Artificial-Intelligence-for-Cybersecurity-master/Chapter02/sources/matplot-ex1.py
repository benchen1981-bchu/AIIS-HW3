import numpy as np 

import matplotlib.pyplot as plt  

plt.plot(np.arange(15), np.arange(15))

plt.show() 

